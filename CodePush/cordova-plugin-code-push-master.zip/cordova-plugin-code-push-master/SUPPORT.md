# Support

## How to file issues and get help
This project uses GitHub Issues to track bugs and feature requests. Please search the existing issues before filing new issues to avoid duplicates. For new issues, file your bug or feature request as a new issue.
For help and questions about using this project, please consider reaching out to the App Center support team using the support feature in your App Center account if you have one - otherwise please create an issue in this repository.

## Microsoft Support Policy
Support for this project is limited to the resources listed above.

