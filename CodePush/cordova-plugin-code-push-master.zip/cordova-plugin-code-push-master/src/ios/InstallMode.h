enum {
    IMMEDIATE = 0,
    ON_NEXT_RESTART = 1,
    ON_NEXT_RESUME = 2
};
typedef NSInteger InstallMode;

