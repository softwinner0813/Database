import AccountManager = require("./management-sdk");
export = AccountManager;
