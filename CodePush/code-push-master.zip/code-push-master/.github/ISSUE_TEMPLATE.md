Thanks so much for filing an issue or feature request! We will address it as soon as we can. Please follow these guidelines:

1. This repository is for the CodePush CLI and management SDK. For issues relating to the CodePush client SDK's, please see:
  * react-native-code-push: https://github.com/Microsoft/react-native-code-push
2. In your description, please include the version of `code-push-cli` or `code-push` that you are using.
