# base on

fork from https://github.com/Microsoft/react-native-code-push examples

# iOS eg.

```shell
$ git clone git@github.com:lisong/code-push-demo-app.git
$ cd code-push-demo-app
$ npm install
$ open ios/CodePushDemoApp.xcodeproj
```

# android eg.

```shell
$ git clone git@github.com:lisong/code-push-demo-app.git
$ cd code-push-demo-app
$ npm install
$ cd android
$ ./gradlew assembleRelease
$ cd app/build/outputs/apk #install app-release.apk into your phone
```

# codepush 热更新

```shell
$ code-push login http://api.code-push.com #登录code-push-server
$ code-push app add CodePushReactNativeDemo-ios ios react-native  #iOS版
$ code-push app add CodePushReactNativeDemo-android android react-native #android版
$ cd code-push-demo-app
$ npm install
$ code-push release-react CodePushReactNativeDemo-ios ios -d Production #发布到code-push-server ios
$ code-push release-react CodePushReactNativeDemo-android android -d Production #发布code-push-server android
```
