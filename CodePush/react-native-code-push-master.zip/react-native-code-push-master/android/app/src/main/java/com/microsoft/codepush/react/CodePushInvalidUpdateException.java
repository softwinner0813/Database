package com.microsoft.codepush.react;

public class CodePushInvalidUpdateException extends RuntimeException {
    public CodePushInvalidUpdateException(String message) {
        super(message);
    }
}
