package com.microsoft.codepush.react;

interface DownloadProgressCallback {
    void call(DownloadProgress downloadProgress);
}
