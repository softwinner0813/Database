﻿namespace CodePush.ReactNative
{
    enum InstallMode
    {
        Immediate,
        OnNextRestart,
        OnNextResume
    }
}