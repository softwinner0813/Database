﻿namespace CodePush.ReactNative
{
    enum UpdateState
    {
        Running,
        Pending,
        Latest
    }
}